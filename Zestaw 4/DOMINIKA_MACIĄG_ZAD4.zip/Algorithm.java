
public interface Algorithm {
    public String crypt(String inputWord);
    public String decrypt(String inputWord);
}
