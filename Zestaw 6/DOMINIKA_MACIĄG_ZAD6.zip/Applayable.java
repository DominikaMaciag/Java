public interface Applayable {

    void apply(Series v);
}
