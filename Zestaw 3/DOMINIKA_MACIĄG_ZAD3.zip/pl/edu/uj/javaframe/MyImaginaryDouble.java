package pl.edu.uj.javaframe;

public class MyImaginaryDouble extends MyDouble{
    public double urojona;
    @Override
    public Value create(String val){
        int i;
        MyImaginaryDouble v = new MyImaginaryDouble();
        String pomocniczy = new String();
        for (i=0;i< val.length(); i++){                // część rzeczywista
            if(val.charAt(i)!='i'){
               pomocniczy += val.charAt(i);
               // System.out.println("----> " + i + " " + pomocniczy );
            }
            else{
                break;
            }
        }
        v.value = Double.parseDouble(pomocniczy);
        pomocniczy = "";
        for (i=i+1; i<=val.length()-1; i++){        // część urojona
            pomocniczy += val.charAt(i);
            // System.out.println("---- >" + pomocniczy );
        }
        v.urojona = Double.parseDouble(pomocniczy);
        return v;
    }

    public Value add(Value v){
        MyImaginaryDouble result  = new MyImaginaryDouble();
        result.value = (Double)this.value + Double.valueOf(v.value.toString());
        result.urojona = this.urojona;
        //System.out.println("add wykonany");
        if(v instanceof MyImaginaryInt ){
            result.urojona += (double)((MyImaginaryInt) v).urojona;
        }
        if(v instanceof MyImaginaryDouble ){
            result.urojona += ((MyImaginaryDouble) v).urojona;
        }
        return result;
    }

    @Override
    public Value sub(Value v) {
        MyImaginaryDouble result  = new MyImaginaryDouble();
        result.value = (Double)this.value - Double.valueOf(v.value.toString());
        result.urojona = this.urojona;
        //System.out.println("sub wykonany");
        if(v instanceof MyImaginaryInt ){
            result.urojona -= (double)((MyImaginaryInt) v).urojona;
        }
        if(v instanceof MyImaginaryDouble ){
            result.urojona -= ((MyImaginaryDouble) v).urojona;
        }
        return result;
    }

    @Override
    public Value mul(Value v) {
        MyImaginaryDouble result  = new MyImaginaryDouble();

        if(v instanceof MyImaginaryInt ){
            result.value = (Double)this.value * Double.valueOf(v.value.toString())
                    - this.urojona * (double)((MyImaginaryInt)v).urojona;

            result.urojona = (Double)this.value * (double)((MyImaginaryInt) v).urojona
                    + this.urojona * Double.valueOf(v.value.toString());
        }
        if(v instanceof MyImaginaryDouble ){
            result.value = (Double)this.value * Double.valueOf(v.value.toString())
                    - this.urojona * ((MyImaginaryDouble)v).urojona;

            result.urojona = (Double)this.value * ((MyImaginaryDouble) v).urojona
                    + this.urojona * Double.valueOf(v.value.toString());
        }
        else {
            result.value = (Double)this.value * Double.valueOf(v.value.toString());
            result.urojona = this.urojona * Double.valueOf(v.value.toString());
        }
        return result;
    }

    @Override
    public Value div(Value v) {
        MyImaginaryDouble result  = new MyImaginaryDouble();
        double denominator_int = (Double.valueOf(v.value.toString())* Double.valueOf(v.value.toString())
                + (double)(((MyImaginaryInt)v).urojona) * (double)(((MyImaginaryInt)v).urojona) );
        double denominator = (Double.valueOf(v.value.toString())* Double.valueOf(v.value.toString())
                + (((MyImaginaryDouble)v).urojona) * (((MyImaginaryDouble)v).urojona) );

        if(v instanceof MyImaginaryDouble ){
            result.value = ((Double)this.value * Double.valueOf(v.value.toString())
                    + this.urojona * ((MyImaginaryDouble)v).urojona) / denominator;
            result.urojona = this.urojona * Double.valueOf(v.value.toString())
                    - (Double)this.value * ((MyImaginaryDouble)v).urojona / denominator;
        }
        if(v instanceof MyImaginaryInt ) {
            result.value = ((Double)this.value * Double.valueOf(v.value.toString())
                    + this.urojona * (double)((MyImaginaryInt)v).urojona) / denominator_int;
            result.urojona = this.urojona * Double.valueOf(v.value.toString())
                    - (Double)this.value * (double)((MyImaginaryInt)v).urojona / denominator_int;
        }
        else {
            result.value = (Double)this.value / Double.valueOf(v.value.toString());
            result.urojona = this.urojona / Double.valueOf(v.value.toString());
        }
        return result;
    }

    @Override
    public Value pow(Value v) {
        MyImaginaryDouble result  = new MyImaginaryDouble();
        result.value = 1;
        result.urojona = 0;
        for ( int i =0; i<Double.valueOf(v.value.toString()); i++){
            result.value = (Double)result.value * Double.valueOf(this.value.toString())
                    - result.urojona * ((MyImaginaryDouble)this).urojona;

            result.urojona = (Double)this.value * ((MyImaginaryDouble) result).urojona
                    + this.urojona * Double.valueOf(result.value.toString());
        }
        return result;
    }

    @Override
    public boolean eq(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Double)this.value == Double.valueOf(v.value.toString())) & (this.urojona == (double)((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Double)this.value == Double.valueOf(v.value.toString())) & (this.urojona == ((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else {
            if (this.urojona != 0)return false;
            else if(this.value == v.value) return true;
            else return false;
        }
    }

    @Override
    public boolean lte(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Double)this.value <= Double.valueOf(v.value.toString())) & (this.urojona <= (double)((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Double)this.value <= Double.valueOf(v.value.toString())) & (this.urojona <= ((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else return false;
    }

    @Override
    public boolean gte(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Double)this.value >= Double.valueOf(v.value.toString())) & (this.urojona >= (double)((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Double)this.value >= Double.valueOf(v.value.toString())) & (this.urojona >= ((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else return false;
    }

    @Override
    public boolean neq(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Double)this.value != Double.valueOf(v.value.toString())) | (this.urojona != (double)((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Double)this.value != Double.valueOf(v.value.toString())) | (this.urojona != ((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else return false;
    }

    @Override
    public int hashCode() {
        return (int)this.value;
    }

    @Override
    public boolean equals(Object other) {
        if(other instanceof Value){
            if(((Value)other) instanceof MyImaginaryInt ) {
                if(((Double)this.value == Double.valueOf(((Value)other).value.toString())) & (this.urojona == (double)((MyImaginaryInt)((Value)other)).urojona)){
                    return true;
                }
                else return false;
            }
            if(((Value)other) instanceof MyImaginaryDouble) {
                if(((Double)this.value == Double.valueOf(((Value)other).value.toString())) & (this.urojona == ((MyImaginaryDouble)((Value)other)).urojona)){
                    return true;
                }
                else return false;
            }
            else {
                if (this.urojona != 0)return false;
                else if(this.value == ((Value)other).value) return true;
                else return false;
            }
        }
        else return false;
    }

    @Override
    public String toString(){
        String pomocniczy = new String();
        pomocniczy += Double.toString((double)this.value);
        pomocniczy += "i";
        pomocniczy += Double.toString(this.urojona);
        return pomocniczy;
    }
}
