package pl.edu.uj.javaframe;
import java.lang.Math;

public class Int extends Value {
    @Override
    public Value create(String val) {
        Int v = new Int();
        v.value = Integer.parseInt(val);
        return v;
    }

    @Override
    public Value add(Value v) {
        Int result  = new Int();
        if(v.value instanceof Integer){
            result.value = (Integer)this.value + (Integer)v.value;
        }
        else {
            result.value = (Integer)this.value + Integer.valueOf(v.value.toString()).intValue();
        }
        return result;
    }

    @Override
    public Value sub(Value v) {
        Int result  = new Int();
        if(v.value instanceof Integer){
            result.value = (Integer)this.value - (Integer)v.value;
        }
        else {
            result.value = (Integer)this.value - Integer.valueOf(v.value.toString()).intValue();
        }
        return result;
    }

    @Override
    public Value mul(Value v) {
        Int result  = new Int();
        if(v.value instanceof Integer){
            result.value = (Integer)this.value * (Integer)v.value;
        }
        else{
            result.value = (Integer)this.value * Integer.valueOf(v.value.toString()).intValue();
        }
        return result;
    }

    @Override
    public Value div(Value v) {
        Int result  = new Int();
        if(v.value instanceof Integer){
            result.value = (Integer)this.value / (Integer)v.value;
        }
        else{
            result.value = (Integer)this.value / Integer.valueOf(v.value.toString()).intValue();
        }
        return result;
    }

    @Override
    public Value pow(Value v) {
        Int result  = new Int();
        if(v.value instanceof Integer){
            result.value = Math.pow((Integer)this.value, (Integer)v.value);
        }
        else{
            result.value = Math.pow((Integer)this.value, Integer.valueOf(v.value.toString()).intValue());
        }
        return result;
    }

    @Override
    public boolean eq(Value v) {
        if(v.value instanceof Integer){
            if((Integer)this.value == (Integer)v.value){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            if((Integer)this.value == Integer.valueOf(v.value.toString()).intValue()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    @Override
    public boolean lte(Value v) {
        if(v.value instanceof Integer){
            if((Integer)this.value <= (Integer)v.value){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            if((Integer)this.value <= Integer.valueOf(v.value.toString()).intValue()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    @Override
    public boolean gte(Value v) {
        if(v.value instanceof Integer){
            if((Integer)this.value >= (Integer)v.value){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            if((Integer)this.value >= Integer.valueOf(v.value.toString()).intValue()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    @Override
    public boolean neq(Value v) {
        if(v.value instanceof Integer){
            if((Integer)this.value != (Integer)v.value){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            if((Integer)this.value != Integer.valueOf(v.value.toString()).intValue()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    @Override
    public boolean equals(Object other) {
        if(other instanceof Value){
            if(((Value)other).value instanceof Integer){
                if((Integer)this.value == (Integer)((Value)other).value){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                if((Integer)this.value == Integer.valueOf(((Value)other).value.toString()).intValue()){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        if(other instanceof Integer){
            if((Integer)this.value == (Integer) other) return true;
            else return false;
        }
        else return false;
    }

    @Override
    public int hashCode() {
        return (int)this.value;
    }
}
