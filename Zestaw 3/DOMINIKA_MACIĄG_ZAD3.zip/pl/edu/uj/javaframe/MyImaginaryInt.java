package pl.edu.uj.javaframe;

public class MyImaginaryInt extends Int{
    public Integer urojona = 0;
    @Override
    public Value create(String val){
        int i;
        MyImaginaryInt v = new MyImaginaryInt();
        String pomocniczy = new String();
        for (i=0;i< val.length(); i++){                // część rzeczywista
            if(val.charAt(i)!='i'){
                pomocniczy += val.charAt(i);
                // System.out.println("----> " + i + " " + pomocniczy );
            }
            else{
                break;
            }
        }
        v.value = Integer.parseInt(pomocniczy);
        pomocniczy = "";
        for (i=i+1; i<=val.length()-1; i++){        // część urojona
            pomocniczy += val.charAt(i);
            // System.out.println("---- >" + pomocniczy );
        }
        v.urojona = Integer.parseInt(pomocniczy);
        return v;
    }

    @Override
    public Value add(Value v){
        MyImaginaryInt result  = new MyImaginaryInt();
        result.value = (Integer)this.value + Integer.valueOf(v.value.toString());
        result.urojona = this.urojona;
        //System.out.println("add wykonany");
        if(v instanceof MyImaginaryInt ){
            result.urojona += ((MyImaginaryInt) v).urojona;
        }
        if(v instanceof MyImaginaryDouble ){
            result.urojona += (int)((MyImaginaryDouble) v).urojona;
        }
        return result;
    }

    @Override
    public Value sub(Value v) {
        MyImaginaryInt result  = new MyImaginaryInt();
        result.value = (Integer)this.value - Integer.valueOf(v.value.toString());
        result.urojona = this.urojona;
        //System.out.println("sub wykonany");
        if(v instanceof MyImaginaryInt ){
            result.urojona -= ((MyImaginaryInt) v).urojona;
        }
        if(v instanceof MyImaginaryDouble ){
            result.urojona -= (int)((MyImaginaryDouble) v).urojona;
        }
        return result;
    }

    @Override
    public Value mul(Value v) {
        MyImaginaryInt result  = new MyImaginaryInt();

        if(v instanceof MyImaginaryInt ){
            result.value = (Integer)this.value * Integer.valueOf(v.value.toString())
                - this.urojona * ((MyImaginaryInt)v).urojona;

            result.urojona = (Integer)this.value * ((MyImaginaryInt) v).urojona
                + this.urojona * Integer.valueOf(v.value.toString());
        }
        if(v instanceof MyImaginaryDouble ){
            result.value = (Integer)this.value * Integer.valueOf(v.value.toString())
                    - this.urojona * (int)((MyImaginaryDouble)v).urojona;

            result.urojona = (Integer)this.value * (int)((MyImaginaryDouble) v).urojona
                    + this.urojona * Integer.valueOf(v.value.toString());
        }
        else {
            result.value = (Integer)this.value * Integer.valueOf(v.value.toString());
            result.urojona = this.urojona * Integer.valueOf(v.value.toString());
        }
        return result;
    }

    @Override
    public Value div(Value v) {
        MyImaginaryInt result  = new MyImaginaryInt();
        int denominator = (Integer.valueOf(v.value.toString())* Integer.valueOf(v.value.toString())
            + (((MyImaginaryInt)v).urojona) * (((MyImaginaryInt)v).urojona) );
        int denominator_double = (Integer.valueOf(v.value.toString())* Integer.valueOf(v.value.toString())
            + (int)(((MyImaginaryDouble)v).urojona) * (int)(((MyImaginaryDouble)v).urojona) );

        if(v instanceof MyImaginaryInt) {
            result.value = ((Integer)this.value * Integer.valueOf(v.value.toString())
                    + this.urojona * ((MyImaginaryInt)v).urojona) / denominator;
            result.urojona = this.urojona * Integer.valueOf(v.value.toString())
                    - (Integer)this.value * ((MyImaginaryInt)v).urojona / denominator;
        }
        if(v instanceof MyImaginaryDouble){
            result.value = ((Integer)this.value * Integer.valueOf(v.value.toString())
                    + this.urojona * (int)((MyImaginaryDouble)v).urojona) / denominator_double;
            result.urojona = this.urojona * Integer.valueOf(v.value.toString())
                    - (Integer)this.value * (int)((MyImaginaryDouble)v).urojona / denominator_double;
        }
        else {
            result.value = (Integer)this.value / Integer.valueOf(v.value.toString());
            result.urojona = this.urojona / Integer.valueOf(v.value.toString());
        }
        return result;
    }

    @Override
    public Value pow(Value v) {
        MyImaginaryInt result  = new MyImaginaryInt();
        result.value = 1;
        result.urojona = 0;
        for ( int i =0; i<Integer.valueOf(v.value.toString()); i++){
            result.value = (Integer)result.value * Integer.valueOf(this.value.toString())
                    - result.urojona * ((MyImaginaryInt)this).urojona;

            result.urojona = (Integer)this.value * ((MyImaginaryInt) result).urojona
                    + this.urojona * Integer.valueOf(result.value.toString());
        }
        return result;
    }

    @Override
    public boolean eq(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Integer)this.value == Integer.valueOf(v.value.toString())) & (this.urojona == ((MyImaginaryInt)v).urojona)){
                    return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Integer)this.value == Integer.valueOf(v.value.toString())) & (this.urojona == (int)((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else {
            if (this.urojona != 0)return false;
            else if(this.value == v.value) return true;
            else return false;
        }
    }

    @Override
    public boolean lte(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Integer)this.value <= Integer.valueOf(v.value.toString())) & (this.urojona <= ((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Integer)this.value <= Integer.valueOf(v.value.toString())) & (this.urojona <= (int)((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else return false;
    }

    @Override
    public boolean gte(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Integer)this.value >= Integer.valueOf(v.value.toString())) & (this.urojona >= ((MyImaginaryInt)v).urojona)){
                return true;
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Integer)this.value >= Integer.valueOf(v.value.toString())) & (this.urojona >= (int)((MyImaginaryDouble)v).urojona)){
                return true;
            }
            else return false;
        }
        else return false;
    }

    @Override
    public boolean neq(Value v) {
        if(v instanceof MyImaginaryInt ) {
            if(((Integer)this.value != Integer.valueOf(v.value.toString())) | (this.urojona != ((MyImaginaryInt)v).urojona)){
                return true; // they are not equal
            }
            else return false;
        }
        if(v instanceof MyImaginaryDouble) {
            if(((Integer)this.value != Integer.valueOf(v.value.toString())) | (this.urojona != (int)((MyImaginaryDouble)v).urojona)){
                return true; // tey are not equal
            }
            else return false;
        }
        else return false;
    }

    @Override
    public int hashCode() {
        return (int)this.value;
    }

    @Override
    public boolean equals(Object other) {
        if(other instanceof Value){
            if(((Value)other) instanceof MyImaginaryInt ) {
                if(((Integer)this.value == Integer.valueOf(((Value)other).value.toString())) & (this.urojona == ((MyImaginaryInt)((Value)other)).urojona)){
                    return true;
                }
                else return false;
            }
            if(((Value)other) instanceof MyImaginaryDouble) {
                if(((Integer)this.value == Integer.valueOf(((Value)other).value.toString())) & (this.urojona == (int)((MyImaginaryDouble)((Value)other)).urojona)){
                    return true;
                }
                else return false;
            }
            else {
                if (this.urojona != 0)return false;
                else if(this.value == ((Value)other).value) return true;
                else return false;
            }
        }
        else return false;
    }

    @Override
    public String toString(){
        String pomocniczy = new String();
        pomocniczy += Integer.toString((int)this.value);
        pomocniczy += "i";
        pomocniczy += Integer.toString(this.urojona);
        return pomocniczy;
    }
}
