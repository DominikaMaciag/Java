package pl.edu.uj.javaframe;
import java.lang.Math;

public class MyDouble extends Value {
    @Override
    public Value create(String val) {
        MyDouble v = new MyDouble();
        v.value = Double.parseDouble(val);
        return v;
    }

    @Override
    public Value add(Value v) {
        MyDouble result  = new MyDouble();
        result.value = (Double)this.value + Double.valueOf(v.value.toString());
        return result;
    }

    @Override
    public Value sub(Value v) {
        MyDouble result  = new MyDouble();
        result.value = (Double)this.value - Double.valueOf(v.value.toString());
        return result;
    }

    @Override
    public Value mul(Value v) {
        MyDouble result  = new MyDouble();
        result.value = (Double)this.value * Double.valueOf(v.value.toString());
        return result;
    }

    @Override
    public Value div(Value v) {
        MyDouble result  = new MyDouble();
        result.value = (Double)this.value / Double.valueOf(v.value.toString());
        return result;
    }

    @Override
    public Value pow(Value v) {
        MyDouble result  = new MyDouble();
        result.value = Math.pow((Double)this.value, Double.valueOf(v.value.toString()));
        return result;
    }

    @Override
    public boolean eq(Value v) {
        if ((Double)this.value == Double.valueOf(v.value.toString())){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public boolean lte(Value v) {
        if ((Double)this.value <= Double.valueOf(v.value.toString())){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public boolean gte(Value v) {
        if ((Double)this.value >= Double.valueOf(v.value.toString())){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public boolean neq(Value v) {
        if ((Double)this.value != Double.valueOf(v.value.toString())){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int)this.value;
    }

    @Override
    public boolean equals(Object other) {
        if(other instanceof Value){
            if(((Value)other).value instanceof MyDouble){
                if((Double)this.value == (Double)((Value)other).value){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                if((Double)this.value == Double.valueOf(((Value)other).value.toString()).intValue()){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        if(other instanceof MyDouble){
            if((Double)this.value == (Double) other) return true;
            else return false;
        }
        else return false;
    }

}
