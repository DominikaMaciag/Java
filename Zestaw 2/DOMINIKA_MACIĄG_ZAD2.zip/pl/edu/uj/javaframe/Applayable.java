package pl.edu.uj.javaframe;

public interface Applayable {

    void apply(Series v);
}
